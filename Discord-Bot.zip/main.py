import discord
import random
import requests 
from random import choice
class MyClient(discord.Client):
    async def on_ready(self):
        print('Logged in as')
        print(self.user.name)
        print(self.user.id)
        print('------')

    async def on_message(self, message):
        if message.author.id == self.user.id:
            return
        if message.content == 'a':
          emoji = discord.utils.get(message.author.guild.emojis, name='ApprehensivePikachu')
        if message.author.id == 614873899573968906:
          if message.content.lower().startswith('!game '):
            if str(message.author) == 'The Guy#2946':
              await client.change_presence(status=discord.Status.idle,activity=discord.Game(name=message.content[6:]))
          if message.content.startswith('.'):
            await message.channel.send('... {0.author.mention}'.format(message))
          discord.utils.get(message.author.guild.emojis, name='')
          if message.content == "...":
            emoji = discord.utils.get(message.author.guild.emojis, name='PikachuFacePalm')
            await message.add_reaction(emoji)
          if message.content == 'cflip':
            choices = ('heads','tails')
            await message.channel.send(choice(choices))
          if message.content.startswith('catgif'):
            await message.channel.send(requests.get('http://thecatapi.com/api/images/get?format=src&type=gif').url + ' :cat:')
          elif message.content.startswith('!cat'):
            await message.channel.send(requests.get('http://thecatapi.com/api/images/get?format=src&type=jpg').url + ' :cat:')
          if message.content == 'dice(6)':
            await message.channel.send(random.randint(1,6))
          if message.content == 'dice(10)':
            await message.channel.send(random.randint(1,10))

client = MyClient()
client.run('NzQxMTA4OTU2NDg2Njk3MDAx.XyyxgA._DUkvX_Z_OYfhew0PZRlKaHF3rE')